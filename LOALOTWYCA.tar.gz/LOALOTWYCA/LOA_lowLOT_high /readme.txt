1. Go to https://132.73.207.247:9090
	It will say the connection is not safe, click advance and proceed anyway. It will add a self-certificate for the connection.

2. Make sure web_video_server node is running on the wyca	