var toggleBtn, backview, fw, bw, left, right;
var fireRate = 100, fireInterval=null;

	var ros = new ROSLIB.Ros({
		url : 'wss://132.73.207.247:9090'
	});

	ros.on('connection', function(){
		console.log('Connected to websocket server.');
	})

	 ros.on('error', function(error) {
	   console.log('Error connecting to websocket server: ', error);
	 });

	  ros.on('close', function() {
	   console.log('Connection to websocket server closed.');
	 });

	  cmd_vel_listener = new ROSLIB.Topic({
	    ros : ros,
	    name : "/truong/cmd_vel/",
	    messageType : 'geometry_msgs/Twist'
	  });


function start(linear, angular){
	move(linear, angular);
	fireInterval = setInterval(move, fireRate, linear, angular);

}

function stop(){
	move(0.0,0.0);
	clearInterval(fireInterval);
}
function move(linear, angular) {
	    var twist = new ROSLIB.Message({
	      linear: {
	        x: linear,
	        y: 0,
	        z: 0
	      },
	      angular: {
	        x: 0,
	        y: 0,
	        z: angular
	      }
	    });
	    cmd_vel_listener.publish(twist);
}

fw = document.getElementById("up");
bw = document.getElementById("down");
left = document.getElementById("left");
right = document.getElementById("right");
fw.addEventListener("mousedown", function(){start(0.1,0.0);},false);
bw.addEventListener("mousedown", function(){start(-0.1,0.0);},false);
left.addEventListener("mousedown", function(){start(0.0,0.2);},false);
right.addEventListener("mousedown", function(){start(0.0,-0.2);},false);
fw.addEventListener("mouseup", stop);
bw.addEventListener("mouseup", stop);
left.addEventListener("mouseup", stop);
right.addEventListener("mouseup", stop);