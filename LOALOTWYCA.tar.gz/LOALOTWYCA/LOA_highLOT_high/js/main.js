

function goWyca(){
	window.location.href="wyca.html";
}

function goPioneer(){
	window.location.href="pioneer.html";
}

var bat_state;

	var ros = new ROSLIB.Ros({
		url : 'wss://132.73.207.247:9090'
	});

	ros.on('connection', function(){
		console.log('Connected to websocket server.');
		document.getElementById("wifi_on").style.display = "block";
	    document.getElementById("wifi_off").style.display = "none";
	})

	 ros.on('error', function(error) {
	   console.log('Error connecting to websocket server: ', error);
	   document.getElementById("wifi_on").style.display = "none";
	   document.getElementById("wifi_off").style.display = "block";
		document.getElementById("b25").style.display = "block";
		document.getElementById("b50").style.display = "none";
		document.getElementById("b75").style.display = "none";
		document.getElementById("b100").style.display = "none";	   
	 });

	  ros.on('close', function() {
	   console.log('Connection to websocket server closed.');
	   document.getElementById("wifi_on").style.display = "none";
	   document.getElementById("wifi_off").style.display = "block";
		document.getElementById("b25").style.display = "block";
		document.getElementById("b50").style.display = "none";
		document.getElementById("b75").style.display = "none";
		document.getElementById("b100").style.display = "none";	   
	 });

	  cmd_vel_listener = new ROSLIB.Topic({
	    ros : ros,
	    name : "/cmd_vel/teleop_safe",
	    messageType : 'geometry_msgs/Twist'
	  });

	  bat_listener = new ROSLIB.Topic({
	  	ros: ros,
	  	name: "/keylo_api/energy/battery_state",
	  	messageType: 'std_msgs/Int8'
	  });


window.setInterval(function(){
	bat_listener.subscribe(function(message){
		bat_state = message.data;
	});
	if(bat_state<=25){
		document.getElementById("b25").style.display = "block";
		document.getElementById("b50").style.display = "none";
		document.getElementById("b75").style.display = "none";
		document.getElementById("b100").style.display = "none";
	}
	else if(bat_state>25 && bat_state<50){
		document.getElementById("b25").style.display = "none";
		document.getElementById("b50").style.display = "block";
		document.getElementById("b75").style.display = "none";
		document.getElementById("b100").style.display = "none";
	}
	else if(bat_state>50 && bat_state<75){
		document.getElementById("b25").style.display = "none";
		document.getElementById("b50").style.display = "none";
		document.getElementById("b75").style.display = "block";
		document.getElementById("b100").style.display = "none";
	}
	else if(bat_state>75){
		document.getElementById("b25").style.display = "none";
		document.getElementById("b50").style.display = "none";
		document.getElementById("b75").style.display = "none";
		document.getElementById("b100").style.display = "block";
	}
},1000);