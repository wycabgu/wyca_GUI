/* global document */
module.exports = function Canvas() {
	return document.createElement('canvas');
};