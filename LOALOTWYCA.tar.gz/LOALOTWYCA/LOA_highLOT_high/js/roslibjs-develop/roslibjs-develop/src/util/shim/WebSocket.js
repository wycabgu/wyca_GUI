module.exports = typeof window !== 'undefined' ? window.WebSocket : WebSocket;
